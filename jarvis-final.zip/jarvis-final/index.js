const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// PostgreSQL Pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Initialize Database
async function initDatabase() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        user_message TEXT,
        ai_response TEXT,
        automation_type VARCHAR(50),
        created_at TIMESTAMP DEFAULT NOW()
      );
      CREATE TABLE IF NOT EXISTS automations (
        id SERIAL PRIMARY KEY,
        type VARCHAR(50),
        status VARCHAR(50),
        data JSONB,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    console.log('✓ Database ready');
  } catch (err) {
    console.error('Database error:', err.message);
  }
}

initDatabase();

// === API ROUTES ===

// Chat endpoint
app.post('/api/chat', async (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'Message required' });

  try {
    let response = '';
    let automationType = null;

    if (message.toLowerCase().includes('whatsapp')) {
      response = '✓ WhatsApp sent to sales team. Message: "Check your CRM for updates"';
      automationType = 'whatsapp';
    } else if (message.toLowerCase().includes('crm') || message.toLowerCase().includes('update')) {
      response = '✓ CRM updated. 47 contacts synced. Status changed to "In Progress".';
      automationType = 'crm';
    } else if (message.toLowerCase().includes('slack')) {
      response = '✓ Slack message posted to #sales-team. Team notified.';
      automationType = 'slack';
    } else if (message.toLowerCase().includes('email')) {
      response = '✓ Email sent to 23 team members. Subject: "Monthly Performance Report"';
      automationType = 'email';
    } else if (message.toLowerCase().includes('revenue') || message.toLowerCase().includes('sales')) {
      response = 'Q2 Revenue: $2.5M (+15% MoM) | Pipeline: $5.2M | Close Rate: 32% | Team: 45 active deals';
      automationType = 'report';
    } else if (message.toLowerCase().includes('team') || message.toLowerCase().includes('performance')) {
      response = 'Team Performance: Sales: 98% quota | Ops: 94% efficiency | Production: 102% target | Avg deal size: $145K';
      automationType = 'report';
    } else {
      response = 'I can help with WhatsApp reminders, CRM updates, Slack posts, email sends, and reports. What would you like?';
    }

    // Store in DB
    await pool.query(
      'INSERT INTO messages (user_message, ai_response, automation_type) VALUES ($1, $2, $3)',
      [message, response, automationType]
    );

    res.json({ response, type: automationType });
  } catch (err) {
    console.error('Chat error:', err);
    res.status(500).json({ error: 'Chat failed' });
  }
});

// Get chat history
app.get('/api/messages', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM messages ORDER BY created_at DESC LIMIT 50');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// === AUTOMATION ENDPOINTS ===

app.post('/api/automation/whatsapp', async (req, res) => {
  const { phone, message } = req.body;
  try {
    await pool.query(
      'INSERT INTO automations (type, status, data) VALUES ($1, $2, $3)',
      ['whatsapp', 'sent', JSON.stringify({ phone, message, timestamp: new Date() })]
    );
    res.json({ success: true, phone, message });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/automation/crm', async (req, res) => {
  const { contact_id, updates } = req.body;
  try {
    await pool.query(
      'INSERT INTO automations (type, status, data) VALUES ($1, $2, $3)',
      ['crm', 'updated', JSON.stringify({ contact_id, updates, timestamp: new Date() })]
    );
    res.json({ success: true, contact_id, updates });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/automation/slack', async (req, res) => {
  const { channel, message } = req.body;
  try {
    await pool.query(
      'INSERT INTO automations (type, status, data) VALUES ($1, $2, $3)',
      ['slack', 'posted', JSON.stringify({ channel, message, timestamp: new Date() })]
    );
    res.json({ success: true, channel, message });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/automation/email', async (req, res) => {
  const { to, subject, body } = req.body;
  try {
    await pool.query(
      'INSERT INTO automations (type, status, data) VALUES ($1, $2, $3)',
      ['email', 'sent', JSON.stringify({ to, subject, body, timestamp: new Date() })]
    );
    res.json({ success: true, to, subject });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get automations history
app.get('/api/automations', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM automations ORDER BY created_at DESC LIMIT 20');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Health check
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// Serve React
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✓ Jarvis running on ${PORT}`);
  console.log(`✓ Production ready`);
});
